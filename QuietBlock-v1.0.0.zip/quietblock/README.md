# QuietBlock — Anti-adblock helper

Chrome / Chromium-based Edge 120+ ke liye **Manifest V3** extension.

**uBlock ko ON hi rehne do.** QuietBlock adblocker nahi hai. Yeh kuch common
DOM/layout-based “Adblock detected” tests ko mask karne ki koshish karta hai.
Har website par kaam karne ya 100% undetectable rehne ki guarantee **nahi** hai.

## Install — 1 minute

1. `QuietBlock-v1.0.0.zip` ko **extract** karo. ZIP ko seedha install nahi karna.
2. Chrome: `chrome://extensions` — Edge: `edge://extensions` kholo.
3. **Developer mode** ON karo.
4. **Load unpacked** click karo.
5. Extracted `quietblock` folder select karo — isi folder mein `manifest.json` hona chahiye.
6. Browser ke Extensions menu se **QuietBlock** pin kar lo.

Folder ko baad mein delete/move mat karna; browser unpacked extension isi se load karta hai.
Work/school-managed browsers unpacked extensions ko block kar sakte hain.
Yeh local, unsigned/unpacked build hai; Chrome Web Store listing nahi hai.

## Use

1. Jis website par warning aa rahi hai, use kholo.
2. QuietBlock icon → **Enable & reload**.
3. Permission pooche toh us website ke liye allow karo. Current tab reload hoga,
   isliye unsaved form ya kaam ho toh pehle save kar lo.
4. uBlock Origin / uBlock Origin Lite ko enabled hi rakho.
5. Popup phir bhi dikhe toh optional **Dismiss adblock popups** ON karke
   **Reload to apply change** click kar sakte ho. Yeh experimental hai aur
   galat panel chhupa sakta hai; zaroorat na ho toh OFF hi rakho.

Site access exact **hostname** ke liye hai: `example.com` aur `www.example.com`
alag entries hain. Us hostname par HTTP + HTTPS, sab paths/ports cover hote hain.
Dusri sites par helper default OFF hai; all-sites access automatically nahi leta.
Enabled hostname ki koi tab pehle se khuli ho toh usse bhi reload karna hoga.

## Band / remove kaise karein

- Current site: QuietBlock → **Turn off & reload**.
- Saved sites: **Site settings** → **Remove** ya **Remove all**.
- Purana injected JavaScript clear karne ke liye affected tabs **reload** karo.
- Page kharab lage aur popup na khule toh browser Extensions page se QuietBlock
  disable/remove karo, phir page reload karo. uBlock ko band karna zaroori nahi.

## Kya karta hai

- Page ke start par, top-level document mein narrow DOM hooks lagata hai.
- Known test names (`adsbox`, `text-ad`, `pub_300x250`, etc.) wale chhote,
  almost-empty bait elements ke zero dimensions / null offset parent ko mask karta hai.
- Unhi elements ke computed display/visibility aur bounding rectangle readings
  ko normal-looking values de sakta hai.
- Optional cleanup explicit adblock text wale short modal-like popups ko hide
  karne ki koshish karta hai. Yeh detection ko pass karwana **nahi** hai.

Website aam taur par installed extensions ki seedhi list nahi dekhti; woh blocked
requests ya page behavior se adblock ka andaaza lagati hai. Yeh helper sirf kuch
page-behavior checks ko handle karta hai — extension ki maujoodgi ko guaranteed
chhupata nahi.

## Important limits

- Blocked ad request, blocked script / missing global, iframe, worker,
  sophisticated browser-API or server-side detection bypass guaranteed nahi.
- Native APIs ki identity / behavior badalta hai; determined website in changes
  ko notice kar sakti hai. All DOM APIs spoof nahi kiye gaye hain.
- Cross-origin / nested iframes mein injection nahi; protection top-level only.
- Asli ads ko unblock, fake ad impressions generate, ya uBlock rules modify nahi karta.
- Withheld video/content restore nahi karta. Login, subscription ya paywall unlock nahi karta.
- Popup cleanup default OFF. Likely subscription, login and payment dialogs
  deliberately skip karta hai; some backdrops/scroll locks reh sakte hain.
- Browser internal pages, extension stores, built-in PDF viewers, `file://` aur
  incognito default setup mein supported nahi hain.
- Koi target website URL provide nahi kiya gaya, isliye specific-site compatibility
  claim nahi hai. Apni real website par test karna zaroori hai.

Agar kaam na kare, website ka exact URL, warning ka text/screenshot, browser version,
aur blocker ka exact naam (Origin ya Lite) bhejo. Site-specific fix assess kiya ja sakta hai.
Apne adblocker ki filter lists bhi updated rakho.

## Privacy & permissions

- `activeTab`: popup kholne par current tab ki URL/hostname samajhne ke liye.
- `scripting`: approved sites par helper ko page start par run karne ke liye.
- `storage`: enabled hostnames aur per-site popup preference local save karne ke liye.
- Optional HTTP/HTTPS host permissions: sirf aapke Enable click ke baad requested
  hostname par page read/modify access. Manifest mein optional wildcards available
  hain, lekin installation par all-sites access grant nahi hota.

No analytics, accounts, remote code, external fonts, telemetry, cookie API,
browsing-history API, or extension-originated network requests in this version.
Popup cleanup sirf matching page text ko tab ke andar inspect karta hai; text
save/upload nahi hota. Saved hostnames local data hain. Remove action optional
site permission bhi revoke karta hai. Uninstall extension data ko hata deta hai.

## Source files

- `manifest.json`: Manifest V3 / minimal permissions.
- `background.js`: optional site permissions and dynamic script registrations.
- `page-guard.js`: narrowly scoped main-world DOM hooks.
- `dismiss.js`: optional, conservative isolated-world popup cleanup.
- `popup.*`, `options.*`, `ui.css`, `icons/`: local UI and assets.

No build step, package installation, API key or remote service required.
Independent helper; uBlock project se affiliated nahi hai.

License: MIT. See `LICENSE.txt`.
